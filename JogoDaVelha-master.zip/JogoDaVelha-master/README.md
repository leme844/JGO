Aplicação criada na IDE Android Studio

Projeto deve ser "Buildado" e instalado em dispositivo android para execução ou emulado.

